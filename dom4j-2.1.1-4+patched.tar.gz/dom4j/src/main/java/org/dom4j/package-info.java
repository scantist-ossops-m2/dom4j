/**
 * Defines the XML Document Object Model in Java interfaces together with some helper classes.
 */
package org.dom4j;